#include <iostream>
#include <cmath>
#include <iomanip>

int main() {
    // Set formatting for clean table output
    std::cout << std::fixed << std::setprecision(12);
    std::cout << std::setw(4) << "k" 
              << std::setw(20) << "x = 2^k" 
              << std::setw(25) << "atan(1/x)" << "\n";
    std::cout << "----------------------------------------------------\n";

    for (int k = 0; k <= 29; ++k) {
        double x = std::pow(2.0, k);
        double result = std::atan(1.0 / x);
        long long res = result *(1LL<< 29);
        
        printf("5'd%d\t: Z_rom = 32'd%lld;\n", k, res);
    }

    return 0;
}